import { Component, OnInit } from '@angular/core';
import {MatCardModule} from '@angular/material/card';
import {AfterViewInit, ViewChild, ElementRef, Injectable} from '@angular/core';
import { Chart } from 'chart.js';
import {HttpClient} from "@angular/common/http";
import {DbService} from "../../service/db.service";
import { ChangeDetectorRef } from '@angular/core';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-present-query9',
  templateUrl: './present-query9.component.html',
  styleUrls: ['./present-query9.component.css']
})
export class PresentQuery9Component implements implements AfterViewInit {
  chart1 = [];
  chart2 = [];
  @ViewChild("mycanvas1") mycanvas1:ElementRef;
  @ViewChild("mycanvas2") mycanvas2:ElementRef;
  constructor(private http: HttpClient, private db:DbService) { }
  dbversion:string;
  data={labels1:[], values1:[];
    labels2:[], values2:[];
    };

  extract_data(data){
    this.data.labels1=[];
    this.data.values1=[];
    this.data.labels2=[];
    this.data.values2=[];
    for(var i=1;i<2;i++){
      this.data.labels1.push(data[i].join_mode);
      this.data.values1.push(data[i].avg_rsvp);
    }
    for(var i=0;i<1;i++){
      this.data.labels2.push(data[i].join_mode);
      this.data.values2.push(data[i].avg_rsvp);
    }

  /**  for (let arr of data){
      this.data.labels.push(arr.join_mode);
      this.data.values.push(arr.avg_rsvp);
    }**/
  }

  ngOnInit(){
    console.log(123)
    this.dbversion=this.db.getDbVersion();
    this.http.get<any>(`https://adbm-final.herokuapp.com/api/database/${this.dbversion}/query/2`).subscribe(
      data =>{
        this.extract_data(data);
        this.ngAfterViewInit();
      
      },
      error =>{
        console.log('esrror');
        this.mock_data();
        this.ngAfterViewInit();

      }
    )
  }
 

  ngAfterViewInit() {
    //console.log(this.mycanvas);
    var ctx =  this.mycanvas1.nativeElement.getContext('2d');
    this.chart1 = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: this.data.labels1,
        datasets: [
          {
            label: "RSVP",
            backgroundColor: ["#3e95cd", "#8e5ea2"],
            data: this.data.values1
          }
        ]
      },
      options: {
        legend: { display: true },
        title: {
          display: true,
          text: 'Find different group join modes'
        }
      }
    });
  }

  var ctx =  this.mycanvas2.nativeElement.getContext('2d');
  this.chart2 = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: this.data.labels2,
      datasets: [
        {
          label: "RSVP",
          backgroundColor: ["#3e95cd", "#8e5ea2"],
          data: this.data.values2
        }
      ]
    },
    options: {
      legend: { display: true },
      title: {
        display: true,
        text: 'Find different group join modes'
      }
    }
  });
}

}
